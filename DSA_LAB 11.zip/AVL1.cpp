#include <iostream>
#include <algorithm>

class TreeNode {
public:
    int value;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int val) : value(val), left(NULL), right(NULL) {}
};

// Function to perform an in-order traversal and print the nodes
void inOrderTraversal(TreeNode* root) {
    if (root) {
        inOrderTraversal(root->left);
        std::cout << root->value << " ";
        inOrderTraversal(root->right);
    }
}

// Function to insert a node into an AVL tree
TreeNode* insert(TreeNode* root, int value) {
    if (root == NULL) {
        return new TreeNode(value);
    }

    if (value < root->value) {
        root->left = insert(root->left, value);
    } else if (value > root->value) {
        root->right = insert(root->right, value);
    } else {
        // Duplicate values are not allowed in AVL trees.
        return root;
    }

    // Update the height of the current node
    int leftHeight = (root->left) ? root->left->value : 0;
    int rightHeight = (root->right) ? root->right->value : 0;
    root->value = 1 + std::max(leftHeight, rightHeight);

    // Perform balancing if necessary (not shown in this code)

    return root;
}

int main() {
    TreeNode* root = NULL;

    // Insert values into the AVL tree
    root = insert(root, 10);
    root = insert(root, 20);
    root = insert(root, 30);
    root = insert(root, 40);
    root = insert(root, 50);
    root = insert(root, 60);

    // Perform in-order traversal to print the nodes
    inOrderTraversal(root);
    std::cout << std::endl;

    // Don't forget to free the allocated memory to avoid memory leaks.
    // This is just a simple example and doesn't include proper memory management.

    return 0;
}

