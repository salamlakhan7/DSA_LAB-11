#include <iostream>
#include <queue>

struct TreeNode {
    int data;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int value) : data(value), left(NULL), right(NULL) {}
};

class BinaryTree {
private:
    TreeNode* root;

public:
    BinaryTree() : root(NULL) {}

    // Function to perform BFS traversal
    void bfsTraversal() {
        if (root == NULL) {
            std::cout << "Tree is empty." << std::endl;
            return;
        }

        std::queue<TreeNode*> nodeQueue;
        nodeQueue.push(root);

        std::cout << "BFS Traversal: ";

        while (!nodeQueue.empty()) {
            TreeNode* current = nodeQueue.front();
            nodeQueue.pop();

            std::cout << current->data << " ";

            if (current->left != NULL) {
                nodeQueue.push(current->left);
            }

            if (current->right != NULL) {
                nodeQueue.push(current->right);
            }
        }

        std::cout << std::endl;
    }

    // Function to insert a value into the binary tree
    void insert(int value) {
        root = insertRecursive(root, value);
    }

private:
    // Recursive function to insert a value into the binary tree
    TreeNode* insertRecursive(TreeNode* node, int value) {
        if (node == NULL) {
            return new TreeNode(value);
        }

        if (value < node->data) {
            node->left = insertRecursive(node->left, value);
        } else {
            node->right = insertRecursive(node->right, value);
        }

        return node;
    }
};

int main() {
    BinaryTree binaryTree;

    // Insert values into the binary tree
    binaryTree.insert(50);
    binaryTree.insert(30);
    binaryTree.insert(70);
    binaryTree.insert(20);
    binaryTree.insert(40);
    binaryTree.insert(60);
    binaryTree.insert(80);

    // Perform BFS traversal
    binaryTree.bfsTraversal();

    return 0;
}

