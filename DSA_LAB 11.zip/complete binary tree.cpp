#include <iostream>
#include <vector>

class CompleteBinaryTree {
private:
    std::vector<int> tree;

public:
    // Constructor
    CompleteBinaryTree() {}

    // Insert a value into the tree
    void insert(int value) {
        tree.push_back(value);
    }

    // Display the tree
    void display() {
        for (int i = 1; i < tree.size(); ++i) {
            std::cout << tree[i] << " ";
        }
        std::cout << std::endl;
    }
};

int main() {
    // Create a complete binary tree
    CompleteBinaryTree cbt;

    // Insert values into the tree
    cbt.insert(1);
    cbt.insert(2);
    cbt.insert(3);
    cbt.insert(4);
    cbt.insert(5);
    cbt.insert(6);
    cbt.insert(7);

    // Display the tree
    std::cout << "Complete Binary Tree: ";
    cbt.display();

    return 0;
}

